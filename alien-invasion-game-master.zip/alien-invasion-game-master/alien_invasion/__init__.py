"""This module contains scripts of Alien Invasion game. -Rahul"""
